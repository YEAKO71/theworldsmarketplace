
import React, { useState, useEffect } from "react";
import logo from "./logo_theworldmarketplace.png";

export default function TheWorldsMarketplace() {
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center mb-6">
        <img src={logo} alt="TheWorldsMarketplace Logo" className="h-16 w-16 mr-4 rounded-full" />
        <h1 className="text-3xl font-bold">TheWorldsMarketplace</h1>
      </div>
      <p className="mb-4 text-gray-700">A global marketplace for buying, selling, bidding, and auctions.</p>
    </div>
  );
}
